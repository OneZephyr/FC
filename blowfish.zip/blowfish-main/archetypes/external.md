---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
externalUrl: ""
summary: ""
showReadingTime: false
_build:
  render: "false"
  list: "local"
---
