window.addEventListener("DOMContentLoaded", (event) => {
  document.querySelectorAll("pre, .highlight-wrapper").forEach((tag) => (tag.dir = "auto"));
});
