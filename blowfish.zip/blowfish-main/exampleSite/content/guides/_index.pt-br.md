---
title: "Receitas"
description: "Receitas, guias e tutoriais para o Blowfish"

cascade:
  showDate: false
  showAuthor: false
  invertPagination: true
---

{{< lead >}}
Receitas, guias e tutoriais para o Blowfish
{{< /lead >}}

**Usuário do Blowfish?** Para adicionar seu guia a esta lista, [confira o template](/guides/template/).

Esta seção contém guias para vários cenários sobre como configurar seu tema. Se você é novo, confira o guia de [Instalação]({{< ref "docs/installation" >}}) para começar ou visite a seção de [Amostras]({{< ref "samples" >}}) para ver o que o Blowfish pode fazer.

---
