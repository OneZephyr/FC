---
title: "Créez votre page d'accueil avec Blowfish et Hugo"
summary: "Il y a tout juste un an, j'ai créé Blowfish, un thème Hugo conçu pour construire ma vision unique de ma page d'accueil personnelle. J'ai également décidé d'en faire un projet open-source. Aujourd'hui, Blowfish s'est transformé en un projet open-source florissant avec plus de 600 étoiles sur GitHub et des centaines d'utilisateurs. Dans ce tutoriel, je vous montrerai comment démarrer et faire fonctionner votre site web en quelques minutes."
description: "Il y a tout juste un an, j'ai créé Blowfish, un thème Hugo conçu pour construire ma vision unique de ma page d'accueil personnelle. J'ai également décidé d'en faire un projet open-source. Aujourd'hui, Blowfish s'est transformé en un projet open-source florissant avec plus de 600 étoiles sur GitHub et des centaines d'utilisateurs. Dans ce tutoriel, je vous montrerai comment démarrer et faire fonctionner votre site web en quelques minutes."
categories: ["Open-Source", "Blowfish"]
tags: ["tutoriel", "blowfish", "hugo"]
externalUrl: "https://n9o.xyz/posts/202310-blowfish-tutorial/"
date: 2023-10-04
draft: false
showauthor: false
authors:
  - nunocoracao
---
