---
title: "Construye tu página de inicio usando Blowfish y Hugo"
summary: "Hace apenas un año, creé Blowfish, un tema de Hugo diseñado para construir mi visión única de mi página de inicio personal. También decidí convertirlo en un proyecto de código abierto. Hoy, Blowfish se ha transformado en un próspero proyecto de código abierto con más de 600 estrellas en GitHub y cientos de usuarios. En este tutorial, te mostraré cómo empezar y tener tu sitio web funcionando en un par de minutos."
description: "Hace apenas un año, creé Blowfish, un tema de Hugo diseñado para construir mi visión única de mi página de inicio personal. También decidí convertirlo en un proyecto de código abierto. Hoy, Blowfish se ha transformado en un próspero proyecto de código abierto con más de 600 estrellas en GitHub y cientos de usuarios. En este tutorial, te mostraré cómo empezar y tener tu sitio web funcionando en un par de minutos."
categories: ["Open-Source", "Blowfish"]
tags: ["tutorial", "blowfish", "hugo"]
externalUrl: "https://n9o.xyz/posts/202310-blowfish-tutorial/"
date: 2023-10-04
draft: false
showauthor: false
authors:
  - nunocoracao
---
