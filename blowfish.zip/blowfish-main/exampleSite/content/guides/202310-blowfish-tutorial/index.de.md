---
title: "Erstellen Sie Ihre Homepage mit Blowfish und Hugo"
summary: "Vor einem Jahr habe ich Blowfish erstellt, ein Hugo-Theme, das meine einzigartige Vision für meine persönliche Homepage verwirklichen sollte. Ich habe mich auch entschieden, es zu einem Open-Source-Projekt zu machen. Heute hat sich Blowfish zu einem florierenden Open-Source-Projekt mit über 600 Sternen auf GitHub und Hunderten von Nutzern entwickelt. In diesem Tutorial zeige ich Ihnen, wie Sie loslegen und Ihre Website in wenigen Minuten zum Laufen bringen."
description: "Vor einem Jahr habe ich Blowfish erstellt, ein Hugo-Theme, das meine einzigartige Vision für meine persönliche Homepage verwirklichen sollte. Ich habe mich auch entschieden, es zu einem Open-Source-Projekt zu machen. Heute hat sich Blowfish zu einem florierenden Open-Source-Projekt mit über 600 Sternen auf GitHub und Hunderten von Nutzern entwickelt. In diesem Tutorial zeige ich Ihnen, wie Sie loslegen und Ihre Website in wenigen Minuten zum Laufen bringen."
categories: ["Open-Source", "Blowfish"]
tags: ["tutorial", "blowfish", "hugo"]
externalUrl: "https://n9o.xyz/posts/202310-blowfish-tutorial/"
date: 2023-10-04
draft: false
showauthor: false
authors:
  - nunocoracao
---
