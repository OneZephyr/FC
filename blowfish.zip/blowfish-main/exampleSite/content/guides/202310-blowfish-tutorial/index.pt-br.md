---
title: "Construa sua página inicial usando Blowfish e Hugo"
summary: "Há apenas um ano, criei o Blowfish, um tema Hugo criado para construir minha visão única para minha página inicial pessoal. Também decidi torná-lo um projeto de código aberto. Hoje, o Blowfish se transformou em um próspero projeto de código aberto com mais de 600 estrelas no GitHub e centenas de usuários. Neste tutorial, mostrarei como começar e ter seu site funcionando em alguns minutos."
description: "Há apenas um ano, criei o Blowfish, um tema Hugo criado para construir minha visão única para minha página inicial pessoal. Também decidi torná-lo um projeto de código aberto. Hoje, o Blowfish se transformou em um próspero projeto de código aberto com mais de 600 estrelas no GitHub e centenas de usuários. Neste tutorial, mostrarei como começar e ter seu site funcionando em alguns minutos."
categories: ["Open-Source", "Blowfish"]
tags: ["tutorial", "blowfish", "hugo"]
externalUrl: "https://n9o.xyz/posts/202310-blowfish-tutorial/"
date: 2023-10-04
draft: false
showauthor: false
authors:
  - nunocoracao
---
