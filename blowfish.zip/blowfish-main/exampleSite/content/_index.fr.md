---
title: "Bienvenue sur Blowfish ! :tada:"
description: "Cette page a été créée avec le thème Blowfish pour Hugo."
---


<div class="flex px-4 py-2 mb-8 text-base rounded-md bg-primary-100 dark:bg-primary-900">
  <span class="flex items-center pe-3 text-primary-400">
    {{< icon "triangle-exclamation" >}}
  </span>
  <span class="flex items-center justify-between grow dark:text-neutral-300">
    <span class="prose dark:prose-invert">Ceci est une démo du layout <code id="layout">background</code>.</span>
    <button
      id="switch-layout-button"
      class="px-4 mx-[3px] !text-neutral !no-underline rounded-md bg-primary-600 hover:!bg-primary-500 dark:bg-primary-800 dark:hover:!bg-primary-700"
    >
      Changer de layout &orarr;
    </button>
  </span>
</div>


```shell
npx blowfish-tools
```

{{< youtubeLite id="SgXhGb-7QbU" label="Démo de Blowfish-tools" >}}


