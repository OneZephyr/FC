---
title: "Um artigo externo"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "O parâmetro front matter `externalUrl` pode ligar a qualquer URL."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

Esta página utiliza o parâmetro front matter `externalUrl` para ligar a um artigo fora deste site Hugo.

É excelente para coisas como ligar a publicações no Medium ou a artigos de investigação que possa ter alojados em sites de terceiros.
