---
title: "Um artigo externo"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "O parâmetro front matter `externalUrl` pode vincular a qualquer URL."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

Esta página usa o parâmetro front matter `externalUrl` para vincular a um artigo fora deste site Hugo.

É ótimo para coisas como vincular a publicações no Medium ou a artigos de pesquisa que você pode ter hospedados em sites de terceiros.
