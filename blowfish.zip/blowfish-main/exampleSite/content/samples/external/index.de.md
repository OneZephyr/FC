---
title: "Ein externer Artikel"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "Der `externalUrl` Front-Matter-Parameter kann auf jede URL verweisen."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

Diese Seite verwendet den `externalUrl` Front-Matter-Parameter, um auf einen Artikel außerhalb dieser Hugo-Website zu verlinken.

Es ist großartig für Dinge wie das Verlinken auf Beiträge auf Medium oder auf wissenschaftliche Arbeiten, die Sie möglicherweise auf Websites von Drittanbietern hosten.
