---
title: "Un article externe"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "Le paramètre front matter `externalUrl` peut lier vers n'importe quelle URL."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

Cette page utilise le paramètre front matter `externalUrl` pour lier vers un article en dehors de ce site Hugo.

C'est idéal pour des choses comme lier vers des publications sur Medium ou vers des articles de recherche que vous pourriez héberger sur des sites tiers.
