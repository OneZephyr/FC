---
title: "Un artículo externo"
date: 2019-01-24
externalUrl: "https://n9o.xyz/projects/"
summary: "El parámetro front matter `externalUrl` puede enlazar a cualquier URL."
showReadingTime: true
build:
  render: "false"
  list: "local"
type: 'sample'
---

Esta página usa el parámetro front matter `externalUrl` para enlazar a un artículo fuera de este sitio Hugo.

Es genial para cosas como enlazar a publicaciones en Medium o a artículos de investigación que puedas tener alojados en sitios web de terceros.
