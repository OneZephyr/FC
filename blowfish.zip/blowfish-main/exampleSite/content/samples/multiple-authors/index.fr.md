---
title: "Auteurs multiples"
date: 2022-10-12
draft: false
description: "Exemple de configuration avec plusieurs auteurs"
tags: ["auteurs", "exemple"]
summary: "Un exemple rapide de comment utiliser plusieurs auteurs."
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

Voici un exemple de ce à quoi ressemblera un article avec plusieurs auteurs.
