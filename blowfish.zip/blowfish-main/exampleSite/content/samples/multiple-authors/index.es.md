---
title: "Múltiples autores"
date: 2022-10-12
draft: false
description: "Ejemplo de configuración con múltiples autores"
tags: ["autores", "ejemplo"]
summary: "Un ejemplo rápido de cómo se podrían usar múltiples autores."
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

Este es un ejemplo de cómo se verá un artículo con múltiples autores.
