---
title: "複数の著者"
date: 2022-10-12
draft: false
description: "複数の著者の設定方法のサンプル"
tags: ["authors", "sample"]
summary: "複数の著者の利用方法の簡単な例。"
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

これは、著者が複数人の記事がどのように見えるかの例です。
