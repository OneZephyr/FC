---
title: "Múltiplos autores"
date: 2022-10-12
draft: false
description: "Exemplo de configuração com múltiplos autores"
tags: ["autores", "exemplo"]
summary: "Um exemplo rápido de como múltiplos autores podem ser usados."
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

Este é um exemplo de como um artigo com múltiplos autores ficará.
