---
title: "Mehrere Autoren"
date: 2022-10-12
draft: false
description: "Beispiel für eine Einrichtung mit mehreren Autoren"
tags: ["autoren", "beispiel"]
summary: "Ein kurzes Beispiel, wie mehrere Autoren verwendet werden können."
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

Dies ist ein Beispiel dafür, wie ein Artikel mit mehreren Autoren aussehen wird.
