---
title: "Échantillons"
description: "Voyez ce qui est possible avec Blowfish."

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true
  invertPagination: true
---

{{< lead >}}
Blowfish donne vie à votre contenu. :heart_eyes:
{{< /lead >}}

Cette section contient quelques pages de démonstration qui montrent comment Blowfish rend différents types de contenu. Vous pouvez également voir une page exemple de [liste de taxonomie]({{< ref "tags" >}}).

_**Note :** Cette page est juste une liste d'articles Blowfish standard et Hugo a été configuré pour générer un type de contenu `samples` et afficher les résumés d'articles._

---
