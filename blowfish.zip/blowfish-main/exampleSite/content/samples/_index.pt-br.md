---
title: "Amostras"
description: "Veja o que é possível com o Blowfish."

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true
  invertPagination: true
---

{{< lead >}}
O Blowfish dá vida ao seu conteúdo. :heart_eyes:
{{< /lead >}}

Esta seção contém algumas páginas de demonstração que mostram como o Blowfish renderiza diferentes tipos de conteúdo. Você também pode ver uma página de exemplo de [listagem de taxonomia]({{< ref "tags" >}}).

_**Nota:** Esta página é apenas uma listagem de artigos padrão do Blowfish e o Hugo foi configurado para gerar um tipo de conteúdo `samples` e exibir resumos de artigos._

---
