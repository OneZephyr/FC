---
title: "Beispiele"
description: "Sehen Sie, was mit Blowfish möglich ist."

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true
  invertPagination: true
---

{{< lead >}}
Blowfish bringt Ihre Inhalte zum Leben. :heart_eyes:
{{< /lead >}}

Dieser Bereich enthält einige Demo-Seiten, die zeigen, wie Blowfish verschiedene Arten von Inhalten rendert. Sie können auch eine Beispiel-[Taxonomie-Auflistung]({{< ref "tags" >}})-Seite sehen.

_**Nebenbei:** Diese Seite ist nur eine Standard-Blowfish-Artikelliste und Hugo wurde so konfiguriert, dass ein `samples`-Inhaltstyp generiert und Artikel-Zusammenfassungen angezeigt werden._

---
