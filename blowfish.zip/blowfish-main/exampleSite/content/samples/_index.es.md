---
title: "Muestras"
description: "Ve lo que es posible con Blowfish."

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true
  invertPagination: true
---

{{< lead >}}
Blowfish da vida a tu contenido. :heart_eyes:
{{< /lead >}}

Esta sección contiene algunas páginas de demostración que muestran cómo Blowfish renderiza diferentes tipos de contenido. También puedes ver una página de ejemplo de [listado de taxonomía]({{< ref "tags" >}}).

_**Nota:** Esta página es solo un listado de artículos estándar de Blowfish y Hugo ha sido configurado para generar un tipo de contenido `samples` y mostrar resúmenes de artículos._

---
