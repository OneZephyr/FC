---
title: "Documentación"
description: "Aprende a usar Blowfish y sus características."

cascade:
  showDate: false
  showAuthor: false
  invertPagination: true
---

{{< lead >}}
Simple, pero potente. Aprende a usar Blowfish y sus características.
{{< /lead >}}

Esta sección contiene todo lo que necesitas saber sobre Blowfish. Si eres nuevo, consulta la guía de [Instalación]({{< ref "docs/installation" >}}) para comenzar o visita la sección de [Ejemplos]({{< ref "samples" >}}) para ver lo que Blowfish puede hacer.

---
