---
title: "Esempio di elenco di tassonomia degli autori"

---
Un rapido esempio di come iniziare a utilizzare le tassonomie degli autori nei tuoi articoli.