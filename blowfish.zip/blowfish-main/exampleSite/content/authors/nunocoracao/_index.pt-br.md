---
title: "Nuno Coração"
---

A incrível bio fictícia do Nuno.
